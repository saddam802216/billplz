<form method="post" action="billplzpost.php">
    <input type="text" name='name' required value='Payer Name Here'>
    <input type="text" name='email' required value='PayerEmailHere@gmail.com'>
    <input type="hidden" name="mobile" value="60121234567">
    <input type="hidden" name="amount" value ="154.30">
    <input type="hidden" name="reference_1_label" value="">
    <input type="hidden" name="reference_1" value="7">
    <input type="hidden" name="reference_2_label" value="">
    <input type="hidden" name="reference_2" value="7">
    <input type="hidden" name="description" value ="apa2">
    <input type="hidden" name="collection_id" value = "">
    <input type="submit">
</form>
